Снимките на книгите и филмите ги няма, защото проекта става повече от 50MB.
Целия проект може да го видите на https://github.com/itcareer-exam-movie-catalog/catalog