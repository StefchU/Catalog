USE catalog;
INSERT INTO categories (name) VALUES
("Action and adventure"),
("Comedy"),
("Crime"),
("Adventure"),
("Drama"),
("Fantasy"),
("Action"),
("Thriller"),
("Sci-Fi"),
("Animation"),
("Biography"),
("Romance"),
("Mystery"),
("Horror"),
("History"),
("Family");
